KARNI FIG FUSION PVT. LTD. WEBSITE
=================================

Files:
- index.html: responsive one-page website

Preview:
Open index.html in any modern browser.

Before publishing:
1. Replace YOUR_EMAIL@example.com in the script with your official business email.
2. Add your verified business phone number and address in the Contact section.
3. Update product descriptions to match your actual formulations, licences and product status.
4. The page is a front-end demo; the enquiry form uses the visitor's email app and does not store submissions.
5. To publish free, create a GitHub repository and upload index.html, then enable GitHub Pages in repository Settings > Pages.

This is a custom static website. It does not include a paid domain or backend database.
